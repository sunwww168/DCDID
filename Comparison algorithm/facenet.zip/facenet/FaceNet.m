function [Z]=FaceNet(W_Cube,K)
lambda=0.8;
    Z = run_snmfEvol(W_Cube,K,lambda);



