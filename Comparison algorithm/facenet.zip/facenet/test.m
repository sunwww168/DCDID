%function []=test()
%% 低版本
clear;clc;
load synfix-z_3.mat;
 [Z]=FaceNet(W_Cube,4)
