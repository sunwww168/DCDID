function [snmfEvolResult] = run_snmfEvol(W_Cube,nbCluster,lambda)
% run_snmfEvol --- the wrapper function for the evolutionary snmf algorithm
%
%	USAGE
%		[NcutEvolResult] = run_snmfEvol(W_Cube,nbCluster,lambda)
%
%	INPUT
%		W_Cube: raw data, cell of T copies of N*N
%		nbCluster: number of latent clusters
%		lambda: fraction of history to be added to the current time
%
%	OUTPUT
%		snmfEvolResult: cluster results
%
%   Written by
%   Yun Chi, July 7, 2008

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% soft graph clustering,
%   evolutionary version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = size(W_Cube,2);
snmfEvolResult = [];
[D, H, logl] = snmf_evol(W_Cube{1}, nbCluster, 1e-6, 500);
HD = full(H)*full(diag(D));
tempResult = ones(size(HD,1),1);
for j = 1:1:size(HD,1)
    temp = HD(j,1);
    for k = 2:1:nbCluster
        if (HD(j,k) > temp)
            temp = HD(j,k);
            tempResult(j,1)=k;
        end
    end
end
snmfEvolResult = [snmfEvolResult tempResult];
fprintf('t = ');
for i = 2:1:T
    fprintf('%d ',i);
    [D, H, logl] = snmf_evol(W_Cube{i}, nbCluster, 1e-6, 500, D, H, lambda, H);
    HD = full(H)*full(diag(D));
    tempResult = ones(size(HD,1),1);
    for j = 1:1:size(HD,1)
        temp = HD(j,1);
        for k = 2:1:nbCluster
            if (HD(j,k) > temp)
                temp = HD(j,k);
                tempResult(j,1)=k;
            end
        end
    end
    snmfEvolResult = [snmfEvolResult tempResult];
end
